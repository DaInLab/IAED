## Fonte: https://dataficacao.wordpress.com/2017/02/21/criando-mapa-brasil-r/

#1) Fazer download do shapefile do Brasil no site do IBGE
##http://downloads.ibge.gov.br/downloads_geociencias.htm
# Instalando os pacotes----
# Lembre-se: na primeira vez que for "rodar" o programa, deve-se instalar os pacotes necessários
#install.packages("rgeos", repos="http://R-Forge.R-project.org", type="source")
#install.packages("maptools")     
#install.packages("spdep")          
#install.packages("cartography")    
#install.packages("tmap")           
#install.packages("leaflet")        
#install.packages("dplyr")
#install.packages("rgdal")
#install.packages("dplyr")
#install.packages("RColorBrewer")

# Carregando os pacotes----
require(rgeos)
library(maptools)     
library(spdep)          
library(cartography)    
library(tmap)           
library(leaflet)        
library(dplyr)
library(rgdal)
library(dplyr)
library(RColorBrewer) 

dsn <- "./data/"
list.files(dsn, pattern='\\.shp$')
#2. Importando shapefile (mapa do Brasil)----
shp <- readOGR(dsn="./data", layer="BRUFE250GC_SIR", stringsAsFactors=FALSE, encoding="UTF-8")
class(shp)

#3. Importando dataset com os dados a serem plotados no mapa----
#“ClassificacaoPontosCorridos.csv” tem os dados dos pontos ganhos por cada clube 
#no Campeonato Brasileiro desde 2003
#Importação do arquivo
pg <- read.csv(paste0(dsn, "ClassificacaoPontosCorridos.csv"), header=T,sep=";", encoding="UTF-8")
##Sumarização dos pontos ganhos por estado, utilizando as funções do o pacote dplyr
pg <- pg %>% group_by(Estado) %>% mutate(cumsum = cumsum(PG))
pg <- pg %>%
  group_by(Estado) %>%
  summarise(Score= max(cumsum))
pg <- as.data.frame(pg)
class(pg)
#4. Importando códigos do IBGE e adicionr ao dataset o campo "UF" ----
ibge <- read.csv(paste0(dsn, "estadosibge.csv"), header=T,sep=",",encoding="UTF-8")
pg <- merge(pg,ibge, by.x = "Estado", by.y = "UF")
# Fazendo a junção entre o dataset e o shapefile----
pg <- merge(shp,pg, by.x = "CD_GEOCUF", by.y = "Código.UF")

#5) Fazer a junção entre o dataset e o shapefile utilizando o código do IBGE
brasileiropg <- merge(shp,pg, by.x = "CD_GEOCUF", by.y = "Código.UF")

#6) Realizando o tratamento e a formatação do data frame espacial
proj4string(brasileiropg) <- CRS("+proj=longlat +datum=WGS84 +no_defs")
Encoding(brasileiropg$NM_ESTADO) <- "UTF-8"
brasileiropg$Score[is.na(brasileiropg$Score)] <- 0

#7) Gerando o mapa
pal <- colorBin("Blues",domain = NULL,n=5) #cores do mapa

state_popup <- paste0("<strong>Estado: </strong>", 
                      brasileiropg$NM_ESTADO, 
                      "<br><strong>Pontos: </strong>", 
                      brasileiropg$Score)
leaflet(data = brasileiropg) %>%
  addProviderTiles("CartoDB.Positron") %>%
  addPolygons(fillColor = ~pal(brasileiropg$Score), 
              fillOpacity = 0.8, 
              color = "#BDBDC3", 
              weight = 1, 
              popup = state_popup) %>%
  addLegend("bottomright", pal = pal, values = ~brasileiropg$Score,
            title = "Pontos Conquistados",
            opacity = 1)