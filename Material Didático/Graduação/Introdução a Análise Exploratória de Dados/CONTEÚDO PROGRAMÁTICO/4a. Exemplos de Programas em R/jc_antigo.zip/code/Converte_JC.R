# Antes de executar o c�digo: verificar se o RStudio est� "apontando" para o diret�rio "C:/JC" (Windows)
# Instalando os "pacotes" / "bibliotecas" utilizadas
# Necess�rio quando for "rodar" o programa pela primeira vez!
#install.packages("pdftools")
#install.packages("xlsx")

library(pdftools)

dat<-pdf_text("./data/JC_Tabela.pdf")
dat <- paste0(dat, collapse = " ")

#pattern <- "Berufsfeuerwehr\\s+Straße(.)*02366.39258"
pattern <- "Cidades\\s+2016(.)*-0,15%"
extract <- regmatches(dat, regexpr(pattern, dat))
pretable <- gsub("Cidades              2016      2017 crescimento  Cidades               2016      2017 crescimento\n", '', extract)
pretable <- gsub('\n', "", pretable)
#pretable <- gsub("%", "%\n", pretable)
pretable <- gsub("%", "\n", pretable)
pretable <- gsub("\n    ", "\n", pretable)
tabela <- (table(strsplit(pretable, "\n")))
df <- data.frame(tabela, stringsAsFactors = TRUE)
df$Var1 <- as.character(df$Var1)
df$Freq <- NULL
#df
format(df, decimal.mark=",")

words <- strsplit(df$Var1, "  ")

#format(words, decimal.mark=",")

i <- 1
last_one <- length(words)
while (i  <= last_one) {
    
    df$cidade[i]  <- sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[1]
    
    k <- 2
    while ((sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[k]) == "" ) k <- k + 1
    df$pop2016[i] <- as.numeric(sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[k])
   
    k <- k + 1
    while ((sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[k]) == "" ) k <- k + 1
    df$pop2017[i] <- as.numeric(sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[k])
   
    k <- k + 1
    while ((sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[k]) == "" ) k <- k + 1
#    df$indice[i]  <- as.numeric(sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[k])
    df$indice[i]  <- sapply(words[i], function (x) gsub("^\\s+|\\s+$", "", x))[k]
    i <- i + 1
}
df$Var1 <- NULL
df

library(xlsx)
write.xlsx(df, "./data/estimativa_regiao.xlsx")

plot(df$pop2017, main="Popula��o Regional - Bauru", xlab="Cidades",  
        ylab="Qtde")

barplot(df$pop2017, main="Popula��o Regional - Bauru", xlab="Cidades",  
        ylab="Qtde", names.arg=df$cidade,
        border="blue")

